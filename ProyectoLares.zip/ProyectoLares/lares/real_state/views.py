from django.shortcuts import render
from .models import RentalData

def rental_prices_view(request):
    data = RentalData.objects.all()
    context = {
        'data': data
    }
    return render(request, 'real_state/rental_prices.html', context)