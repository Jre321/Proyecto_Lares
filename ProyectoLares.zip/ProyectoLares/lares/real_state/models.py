from django.db import models

class RentalData(models.Model):
    city = models.CharField(max_length=100)
    price = models.FloatField()
    property_type = models.CharField(max_length=50)
    platform = models.CharField(max_length=50)
    date = models.DateField()

    def str(self):
        return f"{self.city} - {self.price} ({self.platform})"
