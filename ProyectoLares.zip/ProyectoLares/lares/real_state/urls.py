from django.urls import path
from . import views

urlpatterns = [
    path('rental-prices/', views.rental_prices_view, name='rental-prices'),
]